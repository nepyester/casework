package login_saucedemo

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import cucumber.api.java.en.And
import cucumber.api.java.en.Given
import cucumber.api.java.en.Then
import cucumber.api.java.en.When
import internal.GlobalVariable

public class SauceDemo {

	@Given("I am to sauce demo")
	def loginSauceDemo() {
		WebUI.openBrowser("https://www.saucedemo.com/")
		WebUI.maximizeWindow()
		WebUI.setText(new TestObject().addProperty('xpath', ConditionType.EQUALS, "//input[@id='user-name']"), "standard_user")
		WebUI.setText(new TestObject().addProperty('xpath', ConditionType.EQUALS, "//input[@id='password']"), "secret_sauce")
		WebUI.click(new TestObject().addProperty('xpath', ConditionType.EQUALS, "//input[@id='login-button']"))
		WebUI.takeFullPageScreenshot()
	}

	@When("I want to sort the product ")
	def sortProduct() {
		WebUI.click(new TestObject().addProperty('xpath', ConditionType.EQUALS, "//select[@class='product_sort_container']"), FailureHandling.STOP_ON_FAILURE)
		WebUI.selectOptionByValue(new TestObject().addProperty('xpath', ConditionType.EQUALS, "//select[@class='product_sort_container']"), "za", false)
		WebUI.takeFullPageScreenshot()
	}

	@And("I add product to the cart")
	def addToCart() {
		WebUI.click(new TestObject().addProperty('xpath', ConditionType.EQUALS, "//button[@id='add-to-cart-test.allthethings()-t-shirt-(red)']"), FailureHandling.STOP_ON_FAILURE)
		WebUI.click(new TestObject().addProperty('xpath', ConditionType.EQUALS, "//div[@id='shopping_cart_container']"), FailureHandling.STOP_ON_FAILURE)
		WebUI.click(new TestObject().addProperty('xpath', ConditionType.EQUALS, "//button[@id='checkout']"), FailureHandling.STOP_ON_FAILURE)
		WebUI.takeFullPageScreenshot()
	}

	@And("I enter my first name, last name, and postal code")
	def checkoutInformation() {
		WebUI.setText(new TestObject().addProperty('xpath', ConditionType.EQUALS, "//input[@id='first-name']"), "Nepy")
		WebUI.setText(new TestObject().addProperty('xpath', ConditionType.EQUALS, "//input[@id='last-name']"), "Gulo")
		WebUI.setText(new TestObject().addProperty('xpath', ConditionType.EQUALS, "//input[@id='postal-code']"), "121")
		WebUI.click(new TestObject().addProperty('xpath', ConditionType.EQUALS, "//input[@id='continue']"), FailureHandling.STOP_ON_FAILURE)
		WebUI.takeFullPageScreenshot()
	}

	@And("I verify that my information is displayed correctly")
	def checkoutOverview() {
		String getTshirt = WebUI.getText(new TestObject().addProperty('xpath', ConditionType.EQUALS, "//div[@class='inventory_item_name']"))
		WebUI.verifyMatch(getTshirt, "Test.allTheThings() T-Shirt (Red)", false, FailureHandling.STOP_ON_FAILURE)
		WebUI.takeFullPageScreenshot()
	}

	@Then("the order should be completed successfully")
	def finishCheckout() {
		WebUI.click(new TestObject().addProperty('xpath', ConditionType.EQUALS, "//button[@id='finish']"), FailureHandling.STOP_ON_FAILURE)
		WebUI.takeFullPageScreenshot()
		WebUI.closeBrowser()
	}
}
